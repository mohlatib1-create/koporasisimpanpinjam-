package com.mitrasejahtera.koperasi.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mitrasejahtera.koperasi.ui.*

@Composable
fun CicilanScreen(state: AppState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val loan = state.loan
    var askPin by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf<Receipt?>(null) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        ScreenHeader("Bayar Cicilan", onBack) {
            Card(
                Modifier.padding(16.dp).fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f)),
            ) {
                Column(Modifier.padding(16.dp)) {
                    if (loan == null) {
                        Text("Tidak ada pinjaman aktif", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text("Pinjaman Aktif", color = Color.White, fontSize = 13.sp)
                        Text("Kontrak ${loan.code}", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { loan.paid.toFloat() / loan.tenor },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = Amber,
                            trackColor = Color.White.copy(alpha = 0.8f),
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Angsuran ke-${loan.paid} dari ${loan.tenor}", color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        }

        Column(Modifier.weight(1f).padding(16.dp)) {
            if (loan != null) {
                WhiteCard {
                    InfoRow("Jatuh Tempo", formatDate(loan.dueMillis), bold = true)
                    HorizontalDivider()
                    InfoRow("Tagihan Bulan Ini", rupiah(loan.monthly), bold = true)
                    HorizontalDivider()
                    InfoRow("Pembayaran dari", "Saldo Sukarela (${rupiah(state.saldo)})")
                }
            }
        }

        Box(Modifier.padding(16.dp).navigationBarsPadding()) {
            AppButton("Bayar Sekarang", color = Amber, enabled = loan != null) {
                if (loan != null && state.saldo < loan.monthly) {
                    Toast.makeText(ctx, "Saldo tidak cukup, silakan Top Up", Toast.LENGTH_SHORT).show()
                } else askPin = true
            }
        }
    }

    if (askPin && loan != null) {
        PinDialog(state, onDismiss = { askPin = false }) {
            askPin = false
            val err = state.payInstallment()
            if (err != null) {
                Toast.makeText(ctx, err, Toast.LENGTH_SHORT).show()
            } else {
                val lunas = loan.paid + 1 >= loan.tenor
                receipt = Receipt(
                    if (lunas) "Pinjaman Lunas" else "Cicilan Berhasil",
                    listOf(
                        "Kontrak" to loan.code,
                        "Angsuran" to "ke-${loan.paid + 1} dari ${loan.tenor}",
                        "Dibayar" to rupiah(loan.monthly),
                    ),
                )
            }
        }
    }
    receipt?.let { ReceiptDialog(it) { receipt = null; onBack() } }
}
