package com.mitrasejahtera.koperasi.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

fun rupiah(n: Long): String = "Rp " + NumberFormat.getInstance(Locale("id", "ID")).format(n)

data class Receipt(val title: String, val lines: List<Pair<String, String>>)

@Composable
fun ScreenHeader(
    title: String,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit = {},
) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Green)
            .statusBarsPadding()
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = Color.White)
            }
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        content()
    }
}

@Composable
fun AppButton(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Green,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(26.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
    ) { Text(text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
}

@Composable
fun InfoRow(label: String, value: String, bold: Boolean = false, valueColor: Color = Color.Unspecified) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = if (bold) Color.Unspecified else TextGray, modifier = Modifier.weight(1f))
        Text(
            value,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = valueColor,
        )
    }
}

@Composable
fun WhiteCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp),
    ) { Column(Modifier.padding(16.dp), content = content) }
}

/** Tab pill (mis. Pulsa | Paket Data). */
@Composable
fun SegmentTabs(titles: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFFE5E7EB)).padding(4.dp)
    ) {
        titles.forEachIndexed { i, t ->
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (i == selected) Color.White else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) { Text(t, fontWeight = if (i == selected) FontWeight.SemiBold else FontWeight.Normal) }
        }
    }
}

/** Grid 2 kolom berisi pilihan nominal. items = (judul, subjudul?) */
@Composable
fun OptionGrid(items: List<Pair<String, String?>>, selected: Int, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items.withIndex().toList().chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (i, item) ->
                    val sel = i == selected
                    Column(
                        Modifier
                            .weight(1f)
                            .height(84.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White)
                            .border(
                                BorderStroke(if (sel) 2.dp else 1.dp, if (sel) Green else Color(0xFFE0E0E0)),
                                RoundedCornerShape(14.dp),
                            )
                            .clickable { onSelect(i) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Text(item.first, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        item.second?.let { Text(it, fontSize = 13.sp, color = TextGray) }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun PinField(
    label: String,
    value: String,
    isError: Boolean = false,
    error: String? = null,
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) onChange(it) },
        label = { Text(label) },
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        singleLine = true,
        isError = isError,
        supportingText = { error?.let { Text(it) } },
        modifier = Modifier.fillMaxWidth(),
    )
}

/** Dialog konfirmasi PIN sebelum transaksi. onSuccess dipanggil jika PIN benar. */
@Composable
fun PinDialog(state: AppState, onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Konfirmasi PIN") },
        text = {
            PinField("Masukkan PIN 6 digit", pin, isError = wrong, error = if (wrong) "PIN salah" else null) {
                pin = it; wrong = false
            }
        },
        confirmButton = {
            TextButton(
                enabled = pin.length == 6,
                onClick = { if (state.verifyPin(pin)) onSuccess() else wrong = true },
            ) { Text("Konfirmasi") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

@Composable
fun ReceiptDialog(receipt: Receipt, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(receipt.title) },
        text = { Column { receipt.lines.forEach { InfoRow(it.first, it.second) } } },
        confirmButton = { TextButton(onClick = onClose) { Text("Selesai") } },
    )
}
