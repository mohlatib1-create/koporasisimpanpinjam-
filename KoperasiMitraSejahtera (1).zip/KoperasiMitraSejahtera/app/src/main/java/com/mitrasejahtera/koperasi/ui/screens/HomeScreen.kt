package com.mitrasejahtera.koperasi.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mitrasejahtera.koperasi.ui.*

private data class MenuItem(val label: String, val icon: ImageVector, val route: String)

private val menus = listOf(
    MenuItem("Pulsa", Icons.Filled.PhoneAndroid, "pulsa/0"),
    MenuItem("Paket Data", Icons.Filled.SimCard, "pulsa/1"),
    MenuItem("Token PLN", Icons.Filled.Bolt, "pln"),
    MenuItem("Ajukan\nPinjaman", Icons.Filled.RequestQuote, "pinjaman"),
    MenuItem("Bayar\nCicilan", Icons.Filled.CreditCard, "cicilan"),
    MenuItem("Setor\nSimpanan", Icons.Filled.Savings, "setor"),
)

@Composable
fun HomeScreen(state: AppState, onNavigate: (String) -> Unit, onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        "Beranda" to Icons.Filled.Home,
        "Simpan Pinjam" to Icons.Filled.AccountBalanceWallet,
        "Riwayat" to Icons.Filled.History,
        "Profil" to Icons.Filled.Person,
    )

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icon, label) },
                        label = { Text(label, fontSize = 11.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Green,
                            selectedTextColor = Green,
                            indicatorColor = GreenLight,
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeContent(state, onNavigate, onSeeAll = { tab = 2 })
                1 -> SimpanPinjamTab(state, onNavigate)
                2 -> HistoryTab(state)
                else -> ProfileTab(state, onLogout)
            }
        }
    }
}

@Composable
private fun HomeContent(state: AppState, onNavigate: (String) -> Unit, onSeeAll: () -> Unit) {
    var hideBalance by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Column(
            Modifier.fillMaxWidth().background(Green).statusBarsPadding()
                .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color.White),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Groups, null, tint = Green) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Koperasi Mitra Sejahtera", color = Color.White, fontSize = 13.sp)
                    Text("Halo, ${state.memberName}", color = Color.White, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { onNavigate("notifikasi") }) {
                    Icon(Icons.Filled.Notifications, "Notifikasi", tint = Amber)
                }
            }
            Spacer(Modifier.height(16.dp))
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f)),
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Saldo Sukarela", color = Color.White, fontSize = 13.sp)
                            Spacer(Modifier.width(6.dp))
                            Icon(
                                if (hideBalance) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                "Sembunyikan saldo", tint = Color.White,
                                modifier = Modifier.size(18.dp).clickable { hideBalance = !hideBalance },
                            )
                        }
                        Text(
                            if (hideBalance) "Rp ••••••••" else rupiah(state.saldo),
                            color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                        )
                    }
                    Button(
                        onClick = { onNavigate("setor") },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber),
                    ) { Text("Top Up") }
                }
            }
        }

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            WhiteCard {
                Text("Total Simpanan Pokok & Wajib", color = TextGray, fontSize = 13.sp)
                Text(rupiah(state.simpanan), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }

            WhiteCard {
                menus.chunked(3).forEach { row ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        row.forEach { m ->
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(GreenLight)
                                    .clickable { onNavigate(m.route) }.padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Icon(m.icon, m.label, tint = Green, modifier = Modifier.size(28.dp))
                                Spacer(Modifier.height(6.dp))
                                Text(m.label, fontSize = 12.sp, textAlign = TextAlign.Center, minLines = 2)
                            }
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("TRANSAKSI TERAKHIR", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = onSeeAll) { Text("Lihat semua", color = Green) }
            }
            if (state.transactions.isEmpty()) Text("Belum ada transaksi.", color = TextGray)
            state.transactions.take(5).forEach { TrxRow(it) }
        }
    }
}

@Composable
private fun TrxRow(t: Trx) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(GreenLight),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Filled.SwapHoriz, null, tint = Green) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, fontWeight = FontWeight.Medium)
            Text(t.date, fontSize = 12.sp, color = TextGray)
        }
        Text(
            (if (t.amount > 0) "+" else "-") + rupiah(kotlin.math.abs(t.amount)),
            color = if (t.amount > 0) Green else Color(0xFF111827),
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun SimpanPinjamTab(state: AppState, onNavigate: (String) -> Unit) {
    val loan = state.loan
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Simpan Pinjam", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        WhiteCard {
            InfoRow("Simpanan Pokok & Wajib", rupiah(state.simpanan))
            InfoRow("Saldo Sukarela", rupiah(state.saldo))
            InfoRow("Limit Pinjaman", rupiah(state.limitPinjaman))
        }
        WhiteCard {
            if (loan == null) {
                Text("Tidak ada pinjaman aktif", color = TextGray)
            } else {
                InfoRow("Pinjaman Aktif", loan.code)
                InfoRow("Angsuran", "${loan.paid} dari ${loan.tenor}")
                InfoRow("Tagihan Bulan Ini", rupiah(loan.monthly))
                InfoRow("Jatuh Tempo", formatDate(loan.dueMillis))
            }
        }
        AppButton("Ajukan Pinjaman") { onNavigate("pinjaman") }
        AppButton("Bayar Cicilan", color = Amber) { onNavigate("cicilan") }
        AppButton("Setor Simpanan") { onNavigate("setor") }
    }
}

@Composable
private fun HistoryTab(state: AppState) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Text("Riwayat", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (state.transactions.isEmpty()) Text("Belum ada transaksi.", color = TextGray)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(state.transactions) { TrxRow(it) }
        }
    }
}

@Composable
private fun ProfileTab(state: AppState, onLogout: () -> Unit) {
    var showChangePin by remember { mutableStateOf(false) }
    var confirmLogout by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Profil", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        WhiteCard {
            InfoRow("Nama Anggota", state.memberName)
            InfoRow("Nomor Anggota", state.memberNo)
            InfoRow("Nomor HP", state.memberHp)
        }
        AppButton("Ubah PIN") { showChangePin = true }
        AppButton("Keluar", color = Amber) { confirmLogout = true }
    }

    if (showChangePin) ChangePinDialog(state) { showChangePin = false }
    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            title = { Text("Keluar") },
            text = { Text("Yakin ingin keluar dari akun ini?") },
            confirmButton = { TextButton(onClick = { confirmLogout = false; onLogout() }) { Text("Keluar") } },
            dismissButton = { TextButton(onClick = { confirmLogout = false }) { Text("Batal") } },
        )
    }
}

@Composable
private fun ChangePinDialog(state: AppState, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var newPin2 by remember { mutableStateOf("") }
    val valid = oldPin.length == 6 && newPin.length == 6 && newPin == newPin2

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ubah PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PinField("PIN lama", oldPin) { oldPin = it }
                PinField("PIN baru", newPin) { newPin = it }
                PinField(
                    "Ulangi PIN baru", newPin2,
                    isError = newPin2.isNotEmpty() && newPin != newPin2,
                    error = if (newPin2.isNotEmpty() && newPin != newPin2) "PIN tidak sama" else null,
                ) { newPin2 = it }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    if (state.changePin(oldPin, newPin)) {
                        Toast.makeText(ctx, "PIN berhasil diubah", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    } else {
                        Toast.makeText(ctx, "PIN lama salah", Toast.LENGTH_SHORT).show()
                    }
                },
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}
