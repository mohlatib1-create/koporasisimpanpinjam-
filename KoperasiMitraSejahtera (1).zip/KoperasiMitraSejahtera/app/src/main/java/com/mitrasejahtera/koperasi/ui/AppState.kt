package com.mitrasejahtera.koperasi.ui

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class Trx(val title: String, val date: String, val amount: Long) // amount > 0 = uang masuk
data class Loan(
    val code: String, val principal: Long, val tenor: Int,
    val paid: Int, val monthly: Long, val dueMillis: Long,
)
data class AuthResult(val ok: Boolean, val message: String)

/** Rumus pinjaman (bunga flat 1,5%/bln, biaya admin 1% dipotong saat pencairan). */
object LoanCalc {
    const val BUNGA_PER_BULAN = 0.015
    const val BIAYA_ADMIN = 0.01
    fun monthly(amount: Long, tenor: Int): Long =
        Math.round(amount.toDouble() / tenor + amount * BUNGA_PER_BULAN)
    fun received(amount: Long): Long = Math.round(amount * (1 - BIAYA_ADMIN))
}

fun formatDate(millis: Long): String =
    SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(Date(millis))

/**
 * Penyimpanan data lokal (SharedPreferences, JSON). Semua data anggota, saldo, riwayat,
 * dan pinjaman tersimpan permanen di HP. PIN disimpan dalam bentuk hash SHA-256.
 * Untuk dipakai bersama banyak perangkat, sambungkan ke backend (Retrofit) nanti.
 */
class AppState(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("koperasi_data", Context.MODE_PRIVATE)
    private var members = JSONArray()
    private var idx = -1
    private var pinHash = ""

    var memberNo by mutableStateOf("")
    var memberName by mutableStateOf("")
    var memberHp by mutableStateOf("")
    var saldo by mutableLongStateOf(0L)
    var simpanan by mutableLongStateOf(0L)
    var loan by mutableStateOf<Loan?>(null)
    val transactions = mutableStateListOf<Trx>()
    val paidBills = mutableStateListOf<String>()
    val limitPinjaman = 10_000_000L

    val isLoggedIn: Boolean get() = idx >= 0

    // ---------- Akun ----------
    private fun hash(p: String): String =
        MessageDigest.getInstance("SHA-256").digest("ms|$p".toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun newMemberJson(no: String, name: String, hp: String, pin: String, saldo: Long, simpanan: Long) =
        JSONObject().put("no", no).put("name", name).put("hp", hp).put("pin", hash(pin))
            .put("saldo", saldo).put("simpanan", simpanan)
            .put("trx", JSONArray()).put("paid", JSONArray())

    fun login(id: String, pin: String): AuthResult {
        val key = id.trim()
        for (i in 0 until members.length()) {
            val o = members.getJSONObject(i)
            if (o.getString("no") == key || o.getString("hp") == key) {
                if (o.getString("pin") != hash(pin)) return AuthResult(false, "PIN salah")
                loadMember(i)
                return AuthResult(true, "")
            }
        }
        return AuthResult(false, "Nomor anggota / HP belum terdaftar")
    }

    fun register(name: String, hp: String, pin: String): AuthResult {
        for (i in 0 until members.length()) {
            if (members.getJSONObject(i).getString("hp") == hp) {
                return AuthResult(false, "Nomor HP sudah terdaftar")
            }
        }
        val no = String.format(Locale.US, "%04d", members.length() + 1)
        members.put(newMemberJson(no, name.trim(), hp, pin, 0L, 0L))
        prefs.edit().putString("members", members.toString()).apply()
        return AuthResult(true, no)
    }

    fun logout() {
        persist()
        idx = -1
        memberNo = ""; memberName = ""; memberHp = ""; pinHash = ""
        saldo = 0L; simpanan = 0L; loan = null
        transactions.clear(); paidBills.clear()
    }

    fun verifyPin(pin: String): Boolean = hash(pin) == pinHash

    fun changePin(oldPin: String, newPin: String): Boolean {
        if (!verifyPin(oldPin)) return false
        pinHash = hash(newPin)
        persist()
        return true
    }

    // ---------- Transaksi ----------
    private fun addTrx(title: String, amount: Long) {
        transactions.add(0, Trx(title, formatDate(System.currentTimeMillis()), amount))
        while (transactions.size > 100) transactions.removeAt(transactions.lastIndex)
    }

    /** @return true jika saldo cukup dan transaksi tercatat */
    fun spend(title: String, amount: Long): Boolean {
        if (amount <= 0 || amount > saldo) return false
        saldo -= amount
        addTrx(title, -amount)
        persist()
        return true
    }

    fun deposit(title: String, amount: Long) {
        saldo += amount
        addTrx(title, amount)
        persist()
    }

    /** Setor simpanan wajib, dibayar dari saldo sukarela. @return pesan error atau null */
    fun setorWajib(amount: Long): String? {
        if (amount > saldo) return "Saldo tidak cukup"
        saldo -= amount
        simpanan += amount
        addTrx("Setoran Simpanan Wajib", -amount)
        persist()
        return null
    }

    fun markBillPaid(key: String) {
        paidBills.add(key)
        persist()
    }

    // ---------- Pinjaman ----------
    fun applyLoan(amount: Long, tenor: Int): String? {
        if (loan != null) return "Anda masih memiliki pinjaman aktif"
        if (amount < 500_000L || amount > limitPinjaman) return "Nominal pinjaman tidak valid"
        val year = Calendar.getInstance().get(Calendar.YEAR)
        val due = Calendar.getInstance().apply { add(Calendar.MONTH, 1) }.timeInMillis
        loan = Loan(
            code = "PINJ-$year-${Random.nextInt(100, 1000)}",
            principal = amount, tenor = tenor, paid = 0,
            monthly = LoanCalc.monthly(amount, tenor), dueMillis = due,
        )
        val received = LoanCalc.received(amount)
        saldo += received
        addTrx("Pinjaman Disetujui", received)
        persist()
        return null
    }

    /** @return pesan error atau null jika berhasil */
    fun payInstallment(): String? {
        val l = loan ?: return "Tidak ada pinjaman aktif"
        if (saldo < l.monthly) return "Saldo tidak cukup"
        saldo -= l.monthly
        addTrx("Bayar Cicilan ${l.code}", -l.monthly)
        val paid = l.paid + 1
        loan = if (paid >= l.tenor) null else {
            val next = Calendar.getInstance().apply { timeInMillis = l.dueMillis; add(Calendar.MONTH, 1) }
            l.copy(paid = paid, dueMillis = next.timeInMillis)
        }
        persist()
        return null
    }

    // ---------- Penyimpanan ----------
    private fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("no", memberNo).put("name", memberName).put("hp", memberHp).put("pin", pinHash)
        o.put("saldo", saldo).put("simpanan", simpanan)
        loan?.let {
            o.put(
                "loan",
                JSONObject().put("code", it.code).put("principal", it.principal).put("tenor", it.tenor)
                    .put("paid", it.paid).put("monthly", it.monthly).put("due", it.dueMillis),
            )
        }
        val trx = JSONArray()
        transactions.forEach { trx.put(JSONObject().put("t", it.title).put("d", it.date).put("a", it.amount)) }
        o.put("trx", trx)
        val paid = JSONArray()
        paidBills.forEach { paid.put(it) }
        o.put("paid", paid)
        return o
    }

    private fun persist() {
        if (idx < 0) return
        members.put(idx, toJson())
        prefs.edit().putString("members", members.toString()).apply()
    }

    private fun loadMember(i: Int) {
        val o = members.getJSONObject(i)
        idx = i
        memberNo = o.getString("no")
        memberName = o.getString("name")
        memberHp = o.getString("hp")
        pinHash = o.getString("pin")
        saldo = o.getLong("saldo")
        simpanan = o.getLong("simpanan")
        loan = o.optJSONObject("loan")?.let {
            Loan(
                it.getString("code"), it.getLong("principal"), it.getInt("tenor"),
                it.getInt("paid"), it.getLong("monthly"), it.getLong("due"),
            )
        }
        transactions.clear()
        o.optJSONArray("trx")?.let { a ->
            for (k in 0 until a.length()) {
                val t = a.getJSONObject(k)
                transactions.add(Trx(t.getString("t"), t.getString("d"), t.getLong("a")))
            }
        }
        paidBills.clear()
        o.optJSONArray("paid")?.let { a -> for (k in 0 until a.length()) paidBills.add(a.getString(k)) }
    }

    private fun seedDemo() {
        members.put(newMemberJson("0001", "Ahmad Fauzi", "081234567890", "123456", 1_750_000L, 3_000_000L))
        prefs.edit().putString("members", members.toString()).apply()
        loadMember(0)
        val due = Calendar.getInstance().apply { set(2026, Calendar.DECEMBER, 26) }.timeInMillis
        loan = Loan("PINJ-2026-019", 3_000_000L, 6, 3, 545_000L, due)
        transactions.add(Trx("Setoran Simpanan Sukarela", "28 Sep 2026", 500_000L))
        transactions.add(Trx("Beli Pulsa Telkomsel", "15 Okt 2026", -26_200L))
        transactions.add(Trx("Pinjaman Disetujui", "10 Agu 2026", 2_970_000L))
        persist()
        logout()
    }

    init {
        val raw = prefs.getString("members", null)
        members = try { if (raw != null) JSONArray(raw) else JSONArray() } catch (e: Exception) { JSONArray() }
        if (members.length() == 0) seedDemo()
    }
}
