package com.mitrasejahtera.koperasi.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mitrasejahtera.koperasi.ui.*

private data class Product(val label: String, val price: Long)

private val pulsaList = listOf(
    Product("10.000", 11_200), Product("25.000", 26_200),
    Product("50.000", 51_000), Product("100.000", 100_500),
)
private val paketList = listOf(
    Product("1,5 GB", 15_000), Product("5 GB", 35_000),
    Product("12 GB", 60_000), Product("30 GB", 100_000),
)

private fun detectOperator(num: String): String? = when {
    num.length < 4 -> null
    num.take(4) in listOf("0811", "0812", "0813", "0821", "0822", "0823", "0851", "0852", "0853") -> "Telkomsel"
    num.take(4) in listOf("0814", "0815", "0816", "0855", "0856", "0857", "0858") -> "Indosat"
    num.take(4) in listOf("0817", "0818", "0819", "0859", "0877", "0878") -> "XL"
    num.take(3) == "089" -> "Tri"
    num.take(3) == "088" -> "Smartfren"
    num.startsWith("08") -> "Operator Lain"
    else -> null
}

@Composable
fun PulsaScreen(state: AppState, initialTab: Int = 0, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var phone by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(initialTab) }
    var selected by remember { mutableIntStateOf(0) }
    var askPin by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf<Receipt?>(null) }

    val list = if (tab == 0) pulsaList else paketList
    val product = list[selected]
    val operator = detectOperator(phone)
    val phoneValid = phone.length in 10..13 && operator != null
    val jenis = if (tab == 0) "Pulsa" else "Paket Data"

    Column(Modifier.fillMaxSize().background(Bg).imePadding()) {
        ScreenHeader("Pulsa & Paket Data", onBack)

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            OutlinedTextField(
                value = phone,
                onValueChange = { if (it.length <= 13) phone = it.filter(Char::isDigit) },
                label = { Text("Nomor HP") },
                placeholder = { Text("0812xxxxxxxx") },
                trailingIcon = { operator?.let { Text(it, color = Green, modifier = Modifier.padding(end = 12.dp)) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            SegmentTabs(listOf("Pulsa", "Paket Data"), tab) { tab = it; selected = 0 }
            OptionGrid(list.map { it.label to rupiah(it.price) }, selected) { selected = it }
        }

        Surface(shadowElevation = 8.dp, shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)) {
            Column(Modifier.padding(16.dp).navigationBarsPadding()) {
                InfoRow(jenis, product.label)
                InfoRow("Total Bayar", rupiah(product.price), bold = true)
                Spacer(Modifier.height(8.dp))
                AppButton("Bayar Sekarang", enabled = phoneValid) {
                    if (state.saldo < product.price) {
                        Toast.makeText(ctx, "Saldo tidak cukup, silakan Top Up", Toast.LENGTH_SHORT).show()
                    } else askPin = true
                }
            }
        }
    }

    if (askPin) {
        PinDialog(state, onDismiss = { askPin = false }) {
            askPin = false
            if (state.spend("Beli $jenis $operator ${product.label}", product.price)) {
                receipt = Receipt(
                    "Pembelian Berhasil",
                    listOf(
                        "Jenis" to jenis, "Nomor" to phone, "Operator" to (operator ?: "-"),
                        "Produk" to product.label, "Total" to rupiah(product.price),
                    ),
                )
            } else Toast.makeText(ctx, "Saldo tidak cukup", Toast.LENGTH_SHORT).show()
        }
    }
    receipt?.let { ReceiptDialog(it) { receipt = null; onBack() } }
}
