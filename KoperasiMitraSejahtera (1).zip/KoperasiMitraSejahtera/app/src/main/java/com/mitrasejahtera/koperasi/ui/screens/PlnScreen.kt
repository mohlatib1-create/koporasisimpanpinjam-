package com.mitrasejahtera.koperasi.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mitrasejahtera.koperasi.ui.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

private const val TOKEN_ADMIN = 2_500L
private const val BILL_ADMIN = 2_500L

private val names = listOf("BUDI SANTOSO", "SITI AMINAH", "AGUS PRASETYO", "DEWI LESTARI", "HENDRO WIBOWO", "RINA KUSUMA")
private val tariffs = listOf("R1 / 900 VA", "R1 / 1300 VA", "R1 / 2200 VA")

private data class Bill(
    val custId: String, val name: String, val tariff: String, val period: String, val meter: String,
    val pokok: Long, val denda: Long, val admin: Long,
) {
    val total get() = pokok + denda + admin
    val key get() = "$custId|$period"
}

/**
 * Inquiry simulasi (deterministik dari nomor yang dimasukkan).
 * Untuk data PLN sungguhan, ganti dua fungsi ini dengan panggilan ke API penyedia PPOB.
 */
private fun seedOf(id: String): Long = id.fold(7L) { a, c -> a * 31 + c.code } and Long.MAX_VALUE

private fun lookupCustomer(id: String): String {
    val s = seedOf(id)
    return names[(s % names.size).toInt()] + " - " + tariffs[(s % tariffs.size).toInt()].replace(" ", "")
}

private fun inquiryBill(id: String): Bill {
    val s = seedOf(id)
    val pokok = 100_000L + (s % 400) * 1_000L
    val start = 10_000L + s % 40_000L
    val end = start + pokok / 1_445L
    val period = SimpleDateFormat("MMM yyyy", Locale("id", "ID")).format(Date())
    return Bill(
        id, names[(s % names.size).toInt()], tariffs[(s % tariffs.size).toInt()], period,
        String.format(Locale.US, "%08d - %08d", start, end), pokok, 0L, BILL_ADMIN,
    )
}

private fun generateToken(): String =
    (1..5).joinToString(" ") { String.format(Locale.US, "%04d", Random.nextInt(10_000)) }

@Composable
fun PlnScreen(state: AppState, onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().background(Bg).imePadding()) {
        ScreenHeader("Token & Tagihan PLN", onBack) {
            TabRow(
                selectedTabIndex = tab,
                containerColor = Green,
                contentColor = Color.White,
                indicator = { positions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(positions[tab]),
                        color = Amber,
                    )
                },
            ) {
                listOf("Token Listrik", "Tagihan Listrik").forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                }
            }
        }
        if (tab == 0) TokenTab(state, onBack) else BillTab(state, onBack)
    }
}

@Composable
private fun TokenTab(state: AppState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var meterId by remember { mutableStateOf("") }
    var selected by remember { mutableIntStateOf(0) }
    var askPin by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf<Receipt?>(null) }
    val nominals = listOf(20_000L, 50_000L, 100_000L, 200_000L)
    val valid = meterId.length == 11
    val total = nominals[selected] + TOKEN_ADMIN

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            OutlinedTextField(
                value = meterId,
                onValueChange = { if (it.length <= 11) meterId = it.filter(Char::isDigit) },
                label = { Text(if (valid) "Meter ID (Validated)" else "Meter ID (11 digit)") },
                trailingIcon = { if (valid) Icon(Icons.Filled.CheckCircle, null, tint = Green) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            if (valid) {
                Column {
                    Text("Nama Kustomer", color = TextGray, fontSize = 13.sp)
                    Text(lookupCustomer(meterId), fontWeight = FontWeight.Bold)
                }
            }
            OptionGrid(nominals.map { rupiah(it).removePrefix("Rp ") to null }, selected) { selected = it }
            InfoRow("Biaya Admin", rupiah(TOKEN_ADMIN))
            InfoRow("Total Bayar", rupiah(total), bold = true)
        }
        AppButton("Beli Token", enabled = valid) {
            if (state.saldo < total) {
                Toast.makeText(ctx, "Saldo tidak cukup, silakan Top Up", Toast.LENGTH_SHORT).show()
            } else askPin = true
        }
    }

    if (askPin) {
        PinDialog(state, onDismiss = { askPin = false }) {
            askPin = false
            if (state.spend("Beli Token PLN ${rupiah(nominals[selected])}", total)) {
                val kwh = String.format(Locale("id", "ID"), "%.1f kWh", nominals[selected] / 1444.7)
                receipt = Receipt(
                    "Token Berhasil Dibeli",
                    listOf(
                        "Meter ID" to meterId, "Nama" to lookupCustomer(meterId),
                        "Nominal" to rupiah(nominals[selected]), "kWh" to kwh,
                        "Total" to rupiah(total), "Token" to generateToken(),
                    ),
                )
            } else Toast.makeText(ctx, "Saldo tidak cukup", Toast.LENGTH_SHORT).show()
        }
    }
    receipt?.let { ReceiptDialog(it) { receipt = null; onBack() } }
}

@Composable
private fun BillTab(state: AppState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var custId by remember { mutableStateOf("") }
    var bill by remember { mutableStateOf<Bill?>(null) }
    var askPin by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf<Receipt?>(null) }
    val current = bill
    val alreadyPaid = current != null && current.key in state.paidBills

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = custId,
                    onValueChange = { if (it.length <= 12) { custId = it.filter(Char::isDigit); bill = null } },
                    label = { Text("ID Pelanggan (12 digit)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Button(
                    onClick = { bill = inquiryBill(custId) },
                    enabled = custId.length == 12,
                    colors = ButtonDefaults.buttonColors(containerColor = Amber),
                ) { Text("Cek") }
            }
            if (current != null) {
                WhiteCard {
                    InfoRow("Nama Pelanggan", current.name)
                    InfoRow("Tarif / Daya", current.tariff)
                    InfoRow("Periode Tagihan", current.period)
                    InfoRow("Stand Meter", current.meter)
                    InfoRow("Tagihan Pokok", rupiah(current.pokok))
                    InfoRow("Denda", rupiah(current.denda))
                    InfoRow("Biaya Admin", rupiah(current.admin))
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    InfoRow("Total Bayar", rupiah(current.total), bold = true, valueColor = Green)
                }
                WhiteCard { InfoRow("Sumber Dana", "Saldo Sukarela (${rupiah(state.saldo)})") }
                if (alreadyPaid) Text("Tagihan periode ini sudah dibayar.", color = Green, fontWeight = FontWeight.SemiBold)
            }
        }
        AppButton("Bayar Tagihan", color = Amber, enabled = current != null && !alreadyPaid) {
            val b = current ?: return@AppButton
            if (state.saldo < b.total) {
                Toast.makeText(ctx, "Saldo tidak cukup, silakan Top Up", Toast.LENGTH_SHORT).show()
            } else askPin = true
        }
    }

    if (askPin && current != null) {
        PinDialog(state, onDismiss = { askPin = false }) {
            askPin = false
            if (state.spend("Bayar Tagihan PLN ${current.period}", current.total)) {
                state.markBillPaid(current.key)
                receipt = Receipt(
                    "Pembayaran Berhasil",
                    listOf(
                        "ID Pelanggan" to current.custId, "Nama" to current.name,
                        "Periode" to current.period, "Total" to rupiah(current.total),
                    ),
                )
            } else Toast.makeText(ctx, "Saldo tidak cukup", Toast.LENGTH_SHORT).show()
        }
    }
    receipt?.let { ReceiptDialog(it) { receipt = null; onBack() } }
}
