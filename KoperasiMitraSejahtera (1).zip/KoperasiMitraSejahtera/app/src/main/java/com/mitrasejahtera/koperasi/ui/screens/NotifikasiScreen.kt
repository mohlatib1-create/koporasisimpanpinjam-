package com.mitrasejahtera.koperasi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mitrasejahtera.koperasi.ui.*

@Composable
fun NotifikasiScreen(state: AppState, onBack: () -> Unit) {
    val loan = state.loan
    Column(Modifier.fillMaxSize().background(Bg)) {
        ScreenHeader("Notifikasi", onBack)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (loan != null) {
                item {
                    WhiteCard {
                        Text("Pengingat Cicilan", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Cicilan ${loan.code} sebesar ${rupiah(loan.monthly)} jatuh tempo ${formatDate(loan.dueMillis)}.",
                            color = TextGray, fontSize = 13.sp,
                        )
                    }
                }
            }
            if (state.transactions.isEmpty() && loan == null) {
                item { Text("Belum ada notifikasi.", color = TextGray) }
            }
            items(state.transactions) { t ->
                WhiteCard {
                    Text(t.title, fontWeight = FontWeight.SemiBold)
                    Text("${t.date} • ${rupiah(kotlin.math.abs(t.amount))}", color = TextGray, fontSize = 13.sp)
                }
            }
        }
    }
}
