package com.mitrasejahtera.koperasi.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mitrasejahtera.koperasi.ui.*

@Composable
fun SetorScreen(state: AppState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var nominal by remember { mutableStateOf("") }
    var askPin by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf<Receipt?>(null) }
    val amount = nominal.toLongOrNull() ?: 0L

    Column(Modifier.fillMaxSize().background(Bg).imePadding()) {
        ScreenHeader("Setor Simpanan / Top Up", onBack)
        Column(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SegmentTabs(listOf("Top Up Sukarela", "Simpanan Wajib"), tab) { tab = it }
            WhiteCard {
                InfoRow("Saldo Sukarela", rupiah(state.saldo), bold = true)
                InfoRow("Simpanan Pokok & Wajib", rupiah(state.simpanan))
            }
            OutlinedTextField(
                value = nominal,
                onValueChange = { if (it.length <= 10) nominal = it.filter(Char::isDigit) },
                label = { Text("Nominal (minimal Rp10.000)") },
                prefix = { Text("Rp ") },
                supportingText = { if (amount > 0) Text(rupiah(amount)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                if (tab == 0) "Top Up menambah Saldo Sukarela Anda."
                else "Simpanan Wajib dibayar dari Saldo Sukarela dan menambah Simpanan Pokok & Wajib.",
                color = TextGray, fontSize = 12.sp,
            )
        }
        Box(Modifier.padding(16.dp).navigationBarsPadding()) {
            AppButton(if (tab == 0) "Top Up Sekarang" else "Setor Sekarang", enabled = amount >= 10_000) {
                if (tab == 0) {
                    state.deposit("Setoran Simpanan Sukarela", amount)
                    receipt = Receipt("Top Up Berhasil", listOf("Nominal" to rupiah(amount), "Saldo Baru" to rupiah(state.saldo)))
                } else if (amount > state.saldo) {
                    Toast.makeText(ctx, "Saldo tidak cukup, silakan Top Up", Toast.LENGTH_SHORT).show()
                } else askPin = true
            }
        }
    }

    if (askPin) {
        PinDialog(state, onDismiss = { askPin = false }) {
            askPin = false
            val err = state.setorWajib(amount)
            if (err != null) {
                Toast.makeText(ctx, err, Toast.LENGTH_SHORT).show()
            } else {
                receipt = Receipt(
                    "Setoran Berhasil",
                    listOf("Nominal" to rupiah(amount), "Total Simpanan" to rupiah(state.simpanan)),
                )
            }
        }
    }
    receipt?.let { ReceiptDialog(it) { receipt = null; onBack() } }
}
