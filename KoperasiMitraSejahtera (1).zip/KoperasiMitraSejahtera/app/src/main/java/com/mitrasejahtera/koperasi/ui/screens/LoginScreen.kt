package com.mitrasejahtera.koperasi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mitrasejahtera.koperasi.ui.*

@Composable
fun LoginScreen(state: AppState, onLogin: () -> Unit, onRegister: () -> Unit) {
    var memberId by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var showPin by remember { mutableStateOf(false) }
    var idError by remember { mutableStateOf<String?>(null) }
    var pinError by remember { mutableStateOf<String?>(null) }

    fun submit() {
        idError = if (memberId.length < 4) "Masukkan nomor anggota / nomor HP" else null
        pinError = if (pin.length != 6) "PIN harus 6 digit" else null
        if (idError == null && pinError == null) {
            val r = state.login(memberId, pin)
            if (r.ok) onLogin() else if (r.message.startsWith("PIN")) pinError = r.message else idError = r.message
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).imePadding()) {
        Column(
            Modifier.fillMaxWidth().background(Green).statusBarsPadding()
                .padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 56.dp)
        ) {
            Text("Koperasi\nMitra Sejahtera", color = Color.White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))
            Text("Masuk", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        }

        Column(Modifier.padding(horizontal = 16.dp).offset(y = (-36).dp)) {
            WhiteCard {
                OutlinedTextField(
                    value = memberId,
                    onValueChange = { memberId = it.filter(Char::isDigit); idError = null },
                    label = { Text("Nomor Anggota / Nomor HP") },
                    leadingIcon = { Icon(Icons.Filled.PhoneAndroid, null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    isError = idError != null,
                    supportingText = { idError?.let { Text(it) } },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) { pin = it; pinError = null } },
                    label = { Text("PIN Keamanan 6 Digit") },
                    leadingIcon = { Icon(Icons.Filled.Lock, null) },
                    trailingIcon = {
                        IconButton(onClick = { showPin = !showPin }) {
                            Icon(
                                if (showPin) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = "Tampilkan PIN",
                            )
                        }
                    },
                    visualTransformation = if (showPin) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    isError = pinError != null,
                    supportingText = { pinError?.let { Text(it) } },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(20.dp))
            AppButton("Masuk") { submit() }
            TextButton(onClick = onRegister, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Daftar Anggota Baru", color = Green, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Akun contoh: 081234567890 / PIN 123456",
                color = TextGray, fontSize = 12.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
        }
    }
}
