package com.mitrasejahtera.koperasi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mitrasejahtera.koperasi.ui.AppState
import com.mitrasejahtera.koperasi.ui.KoperasiTheme
import com.mitrasejahtera.koperasi.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KoperasiTheme {
                val nav = rememberNavController()
                val state = remember { AppState(applicationContext) }

                NavHost(navController = nav, startDestination = "login") {
                    composable("login") {
                        LoginScreen(
                            state,
                            onLogin = { nav.navigate("home") { popUpTo("login") { inclusive = true } } },
                            onRegister = { nav.navigate("daftar") },
                        )
                    }
                    composable("daftar") { DaftarScreen(state) { nav.popBackStack() } }
                    composable("home") {
                        HomeScreen(state, onNavigate = { nav.navigate(it) }, onLogout = {
                            state.logout()
                            nav.navigate("login") { popUpTo("home") { inclusive = true } }
                        })
                    }
                    composable(
                        "pulsa/{tab}",
                        arguments = listOf(navArgument("tab") { type = NavType.IntType }),
                    ) { entry ->
                        PulsaScreen(state, entry.arguments?.getInt("tab") ?: 0) { nav.popBackStack() }
                    }
                    composable("pln") { PlnScreen(state) { nav.popBackStack() } }
                    composable("pinjaman") { PinjamanScreen(state) { nav.popBackStack() } }
                    composable("cicilan") { CicilanScreen(state) { nav.popBackStack() } }
                    composable("setor") { SetorScreen(state) { nav.popBackStack() } }
                    composable("notifikasi") { NotifikasiScreen(state) { nav.popBackStack() } }
                }
            }
        }
    }
}
