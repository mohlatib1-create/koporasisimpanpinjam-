package com.mitrasejahtera.koperasi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mitrasejahtera.koperasi.ui.*

@Composable
fun DaftarScreen(state: AppState, onBack: () -> Unit) {
    var nama by remember { mutableStateOf("") }
    var hp by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var hpError by remember { mutableStateOf<String?>(null) }
    var newNo by remember { mutableStateOf<String?>(null) }

    val pinCocok = pin == pin2
    val valid = nama.isNotBlank() && hp.length in 10..13 && hp.startsWith("08") && pin.length == 6 && pinCocok

    Column(Modifier.fillMaxSize().background(Bg).imePadding()) {
        ScreenHeader("Daftar Anggota Baru", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                nama, { nama = it },
                label = { Text("Nama Lengkap") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                hp, { if (it.length <= 13) { hp = it.filter(Char::isDigit); hpError = null } },
                label = { Text("Nomor HP (08xxxxxxxxxx)") }, singleLine = true,
                isError = hpError != null,
                supportingText = { hpError?.let { Text(it) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
            )
            PinField("PIN 6 Digit", pin) { pin = it }
            PinField(
                "Ulangi PIN", pin2,
                isError = pin2.isNotEmpty() && !pinCocok,
                error = if (pin2.isNotEmpty() && !pinCocok) "PIN tidak sama" else null,
            ) { pin2 = it }
        }
        Box(Modifier.padding(16.dp).navigationBarsPadding()) {
            AppButton("Daftar", enabled = valid) {
                val r = state.register(nama, hp, pin)
                if (r.ok) newNo = r.message else hpError = r.message
            }
        }
    }

    newNo?.let { no ->
        AlertDialog(
            onDismissRequest = onBack,
            title = { Text("Pendaftaran Berhasil") },
            text = { Text("Nomor anggota Anda: $no\nSilakan masuk memakai nomor anggota atau nomor HP beserta PIN Anda.") },
            confirmButton = { TextButton(onClick = onBack) { Text("Masuk") } },
        )
    }
}
