package com.mitrasejahtera.koperasi.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mitrasejahtera.koperasi.ui.*
import kotlin.math.roundToLong

@Composable
fun PinjamanScreen(state: AppState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var amountF by remember { mutableFloatStateOf(3_000_000f) }
    var tenor by remember { mutableIntStateOf(6) }
    var askPin by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf<Receipt?>(null) }

    val amount = amountF.roundToLong()
    val diterima = LoanCalc.received(amount)
    val cicilan = LoanCalc.monthly(amount, tenor)
    val hasActiveLoan = state.loan != null

    Column(Modifier.fillMaxSize().background(Bg)) {
        ScreenHeader("Ajukan Pinjaman", onBack) {
            Card(
                Modifier.padding(16.dp).fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f)),
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Limit Tersedia", color = Color.White, fontSize = 13.sp)
                    Text(rupiah(state.limitPinjaman), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (hasActiveLoan) {
                WhiteCard {
                    Text(
                        "Anda masih memiliki pinjaman aktif. Lunasi dulu cicilannya sebelum mengajukan pinjaman baru.",
                        color = Amber, fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            Text("Amount Pinjaman", color = TextGray)
            Text(rupiah(amount), fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Slider(
                value = amountF,
                onValueChange = { amountF = it },
                valueRange = 500_000f..state.limitPinjaman.toFloat(),
                steps = ((state.limitPinjaman - 500_000L) / 500_000L - 1).toInt(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(3, 6, 12).forEach { t ->
                    FilterChip(
                        selected = tenor == t,
                        onClick = { tenor = t },
                        label = { Text("$t Bln", modifier = Modifier.padding(vertical = 4.dp)) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true, selected = tenor == t,
                            borderColor = Color(0xFFD1D5DB), selectedBorderColor = Green,
                        ),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color.White),
                    )
                }
            }
            WhiteCard {
                InfoRow("Dana Diterima", rupiah(diterima), bold = true)
                InfoRow("Bunga", "1,5%/bln", bold = true)
                InfoRow("Cicilan", "${rupiah(cicilan)}/bln", bold = true)
            }
            Text("Biaya admin 1% dipotong dari dana yang dicairkan. Dana masuk ke Saldo Sukarela.", color = TextGray, fontSize = 12.sp)
        }

        Box(Modifier.padding(16.dp).navigationBarsPadding()) {
            AppButton("Ajukan Pinjaman", enabled = !hasActiveLoan) { askPin = true }
        }
    }

    if (askPin) {
        PinDialog(state, onDismiss = { askPin = false }) {
            askPin = false
            val err = state.applyLoan(amount, tenor)
            if (err != null) {
                Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
            } else {
                receipt = Receipt(
                    "Pinjaman Disetujui",
                    listOf(
                        "Kontrak" to (state.loan?.code ?: "-"),
                        "Pinjaman" to rupiah(amount), "Tenor" to "$tenor bulan",
                        "Dana Diterima" to rupiah(diterima), "Cicilan" to "${rupiah(cicilan)}/bln",
                    ),
                )
            }
        }
    }
    receipt?.let { ReceiptDialog(it) { receipt = null; onBack() } }
}
