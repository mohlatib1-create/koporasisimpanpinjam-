package com.mitrasejahtera.koperasi.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Green = Color(0xFF0B6B4D)
val GreenLight = Color(0xFFD7EBDF)
val Amber = Color(0xFFC8820E)
val AmberLight = Color(0xFFF7E8CC)
val Bg = Color(0xFFF4F6F5)
val TextGray = Color(0xFF6B7280)

@Composable
fun KoperasiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            secondary = Amber,
            background = Bg,
            surface = Color.White,
        ),
        content = content,
    )
}
